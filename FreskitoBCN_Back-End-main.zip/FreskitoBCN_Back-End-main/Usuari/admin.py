from django.contrib import admin
from .models import Usuari

admin.site.register(Usuari)