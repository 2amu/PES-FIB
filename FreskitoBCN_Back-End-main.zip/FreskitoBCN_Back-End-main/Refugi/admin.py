from django.contrib import admin
from .models import Refugi

admin.site.register(Refugi)