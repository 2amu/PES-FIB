package com.example.freskitobcn.Xat

data class ChatMessage(
    val mensaje: String,
    val userid: String,
    val username: String,
    val timestamp: String
)