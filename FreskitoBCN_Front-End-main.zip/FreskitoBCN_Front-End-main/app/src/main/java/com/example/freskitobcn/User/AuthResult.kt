package com.example.freskitobcn.User

data class AuthResult(val token: String, val userId: String)