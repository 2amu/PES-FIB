package com.example.freskitobcn.User

data class UserProfile(
    val username: String,
    val first_name: String,
    val last_name: String,
    val idioma: String
)