# FreskitoBCN_Front-End
Requisitos:
    Descargar Android Studio: https://developer.android.com/studio?hl=es-419
    Android 10.0 (viene con el IDE)